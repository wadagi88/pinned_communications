Pinned email kit
================

The rules are NOT in this archive. They are on the Email page:

    https://pinnedcomms.netlify.app/email.html

That page is canonical for rules; IMPLEMENTATION.md in here is canonical for
destinations — which file goes to which repo. Stating a rule in both places is
how the two drift.

Contents
--------
  pinned-email-template.html   the shell  -> app/views/layouts/mailer.html.erb
  pinned-email-blocks.html     7 blocks   -> the Messaging Centre composer
  psv-pitch.html               example    -> AdminApi.messaging.templates
  IMPLEMENTATION.md            where each piece goes, and the merge tokens
  assets/*.png                 the lockup at 2x -> a stable HTTPS path

Before you edit the HTML
------------------------
Read https://pinnedcomms.netlify.app/email.html#markup first. The tables, the
inline CSS, the MSO conditional block and the VML button are load-bearing —
each one is there for a client you are probably not testing in.

Generated from the pinned-comms surface, build 26.
